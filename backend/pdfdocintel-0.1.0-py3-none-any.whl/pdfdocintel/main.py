import argparse;
import os;
import sys;
import config;
import spacy;
import numpy as np
from parm_config import ParmConfig;
import utilities.file_util as file_util;
import utilities.parse_util as parse_util;
from logger_config import configure_logger;
import extractors.text_extractor as text_extractor;
from extractors.toc_extractor import extract_toc;
import extractors.table_extractor as table_extractor;
import generators.embeddings_generator as embedding_generator;
import data.pinecone_vector_db as pcne_db;
import data.graph_db as graph_db;


def main(pdf_filename: str):
    
    #TEMPORARY CODE
    #This will be passed in as a parameter
    
    #parm_config = ParmConfig()
    parm_config = ParmConfig(input_dir="../files/uploads", output_dir="../files/output", json_dir="json", text_dir="text", 
                             csv_dir="csv", downloads_dir="../files/downloads/api_responses", query_dir="query_results")
    print("Processing file: ", pdf_filename)
    
    print("Input directory: ", parm_config.input_dir)
    print("Output directory: ", parm_config.output_dir)
    print("Text directory: ", parm_config.get_output_text_dir())
    print("JSON directory: ", parm_config.get_output_json_dir())
    print("CSV directory: ", parm_config.get_output_csv_dir())
    print("Downloads directory: ", parm_config.get_downloads_dir())
    print("Query directory: ", parm_config.get_output_query_dir())
    
    #sys.exit(1)
    
    #Load the spacy model
    nlp = spacy.load(config.SPACY_MODEL)
    
    pdf_prefix = pdf_filename[:3]

    # Path to your PDF file
    pdf_path =  os.path.join(parm_config.input_dir, pdf_filename)

    parsed_pdf_txt_file_name = file_util.generate_filename(f'{pdf_prefix}_extracted')
    parsed_pdf_txt_path = os.path.join(parm_config.get_output_text_dir(), parsed_pdf_txt_file_name)

    pdfminer_txt_file_name = file_util.generate_filename(f'{pdf_prefix}_pdfminer_extract')
    pdfminer_txt_path = os.path.join(parm_config.get_output_text_dir(), pdfminer_txt_file_name)

    toc_ouput_file_name = file_util.generate_filename(f'{pdf_prefix}_TOC')
    toc_output_path = os.path.join(parm_config.get_output_text_dir(), toc_ouput_file_name)

    json_ouput_file_name = file_util.generate_filename(f'{pdf_prefix}_json_output',extension="json")
    json_output_path = os.path.join(parm_config.get_output_json_dir(), json_ouput_file_name)

    json_table_output_file_name = file_util.generate_filename(f'{pdf_prefix}_json_table_output',extension="json")
    json_table_output_path = os.path.join(parm_config.get_output_json_dir(), json_table_output_file_name)
    
    api_response_path = parm_config.get_downloads_dir()
    
    # Add logging here ...
    # Create a custom logger instance.
    logger = configure_logger(__name__)
    
    logger.info(f"Processing file: {pdf_path}")
    
    logger.debug(f"Parse PDF text file: {parsed_pdf_txt_path}")
    logger.debug(f"PDFminer text file: {pdfminer_txt_path}")
    logger.debug(f"TOC output file: {toc_output_path}")
    logger.debug(f"JSON output file: {json_output_path}")
    logger.debug(f"JSON table output file: {json_table_output_path}")
    logger.debug(f"API response path: {api_response_path}")
    
    #sys.exit(1)
    try:
        #Extract text from the PDF file
        pdf_text = text_extractor.extract_text_from_pdf(pdf_path)
        file_util.save_file(parsed_pdf_txt_path, pdf_text)
        
        logger.info(f"Extracted text from PDF file: {parsed_pdf_txt_path}")
        
        #Extract Table of Contents ...
        extract_toc(pdf_path, toc_output_path)
        
        logger.info(f"Extracted Table of Contents from PDF file: {toc_output_path}")
        
        #Capture list of lines from Table of Contents 
        lines_list = file_util.read_lines_into_list(toc_output_path)
        
        header_footer_dict = parse_util.get_header_footer_text(pdf_path,top_margin=50)
        
        
        text_extractor.convert_pdf_to_json(pdf_path,pdfminer_txt_path,json_output_path,lines_list,nlp,header_footer_dict)
            
        logger.info(f'PDF text has been sucessfully converted to JSON {json_output_path}.')
        
        #TODO: Complete this refactoring 01-31-2025 @2:48 AM...
        
        unstructured_api_key = os.environ.get("UNSTRUCTURED_API_KEY")
        if(unstructured_api_key):
            logger.debug("Unstructured API Key is available!")
            #Extract tables from the response of the Unstructured API and save to JSON file.
            extracted_data = table_extractor.extract_tables_from_unstructured_response(pdf_path, api_response_path, json_table_output_path)
            #Save extracted data to JSON file
            file_util.save_json_file(extracted_data, json_table_output_path)
        else:
            logger.debug("\n###Unstructured API Key is not available!\n")

            tables_data = table_extractor.extract_table_content_from_pdf(pdf_prefix, pdf_path, parm_config.get_output_text_dir() ,header_footer_dict)
            
            file_util.write_list_of_table_objects_to_json_file2(tables_data, json_table_output_path)
            
       
        #Get document sections
        sections = text_extractor.get_document_sections(json_output_path)
            

        #Get embeddings from document sections
        embeddings = embedding_generator.generate_embeddings(sections)
        
        # Save the array as a .npy file
        embeddings_file_name = file_util.generate_filename(f'{pdf_prefix}_embeddings',extension="npy")
        embeddings_file_path = os.path.join(parm_config.get_output_dir(), embeddings_file_name)
        np.save(embeddings_file_path, embeddings)
        logger.info(f'Embeddings have been sucessfully saved to file: {embeddings_file_path}')
        
        #Create/add to index on Pinecone
        
        pinecone_api_key=os.environ.get("PINECONE_API_KEY")
            
        strip_file_name = parse_util.strip_non_alphanumeric(pdf_filename)
  

        pinecond_db = pcne_db.PineConeVectorDB(pinecone_api_key,strip_file_name)
        
        pinecond_db.add_embeddings_to_pinecone_index(embeddings)
        logger.info(f'Embeddings have been sucessfully added to index: {pinecond_db.index_name}')
        
        #Query graph db on Neo4j Aurara
        #Iterate through nodes of Graph DB to query vector db
        db_name = os.environ.get("NEO4J_DB_NAME")
        uri = os.environ.get("AURORA_URI")
        user_id = os.environ.get("USER_ID")
        auth_key = os.environ.get("NEO4J_AUTH")
        
        logger.debug(f"DB Name: {db_name}")
        logger.debug(f"URI: {uri}")
        logger.debug(f"User ID: {user_id}") 
        logger.debug(f"Auth Key: {auth_key}")
        
         # Check if any of the variables are None
         # If any variable is None, raise an error
         # You can customize the error message as needed
        if(db_name == None or uri == None or user_id == None or auth_key== None ):
            logger.error("One or more environment variables are missing. Please set them and try again.")
            sys.exit(1)
        logger.debug("All environment variables are set.")
                
        neo4j_graph_db = graph_db.GraphDB(db_name, uri, user_id, auth_key)
        logger.info(f'Graph DB instantiated : {neo4j_graph_db.db_name}')
        #Get Records from Graph Db query
        records = neo4j_graph_db.get_prompts_graphdb()
            
        logger.info(f'Number of records returned from Graph DB: {len(records)}')
                
        #Query Pinecone and output search results to file 
        i = 0
        # Loop through results and do something with them
        for record in records:
            llm_prompt = record['Prompt']
            keyword = record['Keyword']

            results = pinecond_db.get_vectordb_search_results(llm_prompt)
            logger.debug(f'Query used on Pinecone: {llm_prompt}')

            keyword = keyword.replace(" ", "_")
            #Save vector search results to file
            file_name = f'{pdf_prefix}_results_vector_{keyword}'
            file_name = file_util.generate_filename(file_name, extension='json')
            full_path = os.path.join(parm_config.get_output_query_dir(), file_name)
            if results and results.get("matches"):
                file_util.save_file(full_path,results)
                    
            pinecond_db.output_search_results_to_file(pdf_prefix, keyword, results, sections, parm_config.get_output_query_dir())
            i += 1  
              
    except Exception as e:
        print(f"An error occurred: {e}")
        logger.error(f"An error occurred: {e}")
        
if __name__ == "__main__":
    # Set up argument parser
    parser = argparse.ArgumentParser(description="Process a PDF file and format the output.")
    parser.add_argument("pdf_filename", help="Path to the input PDF file")
        #parser.add_argument("config", help="Config class for the output")
        
     # Parse arguments
    args = parser.parse_args()
    
        #filename = "test_file.pdf"
        #config = Config(output_dir = "./output", text_dir="./text", json_dir="./json")
        #result = main(filename)
        #print(result)
        
         # Call the main function with parameters
    try:
        result = main(args.pdf_filename)
        print(result)
    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)
