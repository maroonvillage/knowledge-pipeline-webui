import argparse;
import csv
from datetime import datetime
import json
from logger_config import configure_logger;
import os
import re
from typing import Dict, List
import utilities.parse_util as parse_util

def json_to_csv_table_layout(json_data: List[Dict], output_json_file_path: str) -> None:
    """
     Parses JSON data representing multiple tables and saves them to a CSV file while trying to match the original visual structure.

    Parameters:
        json_data (List[Dict]): The JSON data containing tables with columns and rows.
        output_json_file_path (str): The path to save the CSV file.
    """
    logger = configure_logger(__name__)
    try:
        if not json_data:
            logger.warning("The json data is empty.")
            return
        
        with open(output_json_file_path, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            for table in json_data:
                  title = table.get("title", "")
                  tbl_match = parse_util.find_table_pattern(title)
                  if not tbl_match:
                    logger.debug(f'skipping non-table title: {title}')
                    continue #Skips if the title does not match table pattern

                  writer.writerow([title]) # Write the title
                  columns = table.get("columns", []) # Get the columns
                  rows = table.get("rows", []) # Get the rows
                  writer.writerow(columns) #Write header row

                  if rows:
                      for row in rows:
                        row_values = []
                        for col in columns:
                            row_values.append(row.get(col,"")) #Extract column data from the row
                        if not columns:
                            #If there are not columns, then iterate though the row dictionary
                           for value in row.values():
                                 row_values.append(value)
                        writer.writerow(row_values)
                  else:
                    logger.warning(f"No data to output for table: {title}")
    
        logger.info(f"Successfully wrote json data to csv file: {output_json_file_path}")
    except FileNotFoundError as e:
        logger.error(f"FileNotFoundError: {e} when saving to file: {output_json_file_path}")
    except Exception as e:
         logger.error(f"An unexpected error occurred: {e} when processing data from the JSON: {json_data}. File: {output_json_file_path}")
              
if __name__ == '__main__':
    # Example Usage
    logger = configure_logger(__name__)

    # Set up argument parser
    parser = argparse.ArgumentParser(description="Converts JSON data to CSV format.")
    
    parser.add_argument("pdf_file_name", help="Name of the PDF file.")
    parser.add_argument("output_json_path", help="Path to output JSON files.")
    parser.add_argument("output_csv_path", help="Path to save the output CSV file.")
        
        
     # Parse arguments
    args = parser.parse_args()
    #Get the first three characters of the PDF file name
    prefix = args.pdf_file_name[:3]
    
     # Get the current date and time
    now = datetime.now()
    # Format the date and time as a string (e.g., '2023-04-06_14-30-00')
    timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
    # Combine the base name, timestamp, and extension to form the file name
    output_file = f"{prefix}table_json_to_csv_{timestamp}.csv"
    
    full_output_path = os.path.join(args.output_csv_path, output_file)
    
    first_file = True
    try:
       
        for filename in os.listdir(args.output_json_path):
            if 'json_table_output' in filename and filename.endswith('.json'):
                 json_file_path = os.path.join(args.output_json_path, filename)
                 logger.info(f"Processing file: {json_file_path}")
                 json_data = {}
                 try:
                    with open(json_file_path, 'r') as f:
                        json_data = json.load(f)
                        json_to_csv_table_layout(json_data, full_output_path)
                        first_file = False
                 except FileNotFoundError as e:
                     logger.error(f"File not found: {json_file_path}. Error: {e}")
                 except json.JSONDecodeError as e:
                     logger.error(f"JSONDecodeError: {e} when loading file: {json_file_path}. Error: {e}")
                 except Exception as e:
                     logger.error(f"An unexpected error occurred: {e} when processing file: {json_file_path}. Error: {e}")
    except FileNotFoundError as e:
         logger.error(f"FileNotFoundError: {e} when listing files in folder: {args.output_csv_path}. Error: {e}")
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e} when processing files in folder: {args.output_csv_path}. Error: {e}")