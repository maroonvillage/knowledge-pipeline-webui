SPACY_MODEL = "en_core_web_sm"
GRAPH_DB = {
    "url": "bolt://localhost:7687",
    "db_name": "neo4j"
}