import csv
from datetime import datetime
import json
from logger_config import configure_logger;
import os
from typing import Dict, Any
import argparse

def json_to_csv_with_max_score(json_data: Dict[str, Any], output_file_path: str, write_header: bool = True) -> None:
    """
    Parses JSON data representing search results and saves the title and the content with the highest score for each section, to a CSV file.

    Args:
        json_data (Dict[str, Any]): The JSON data containing search results.
        output_file_path (str): The path to save the CSV file.
        write_header (bool): A flag that will write the header if set to true.
    """
    logger = configure_logger(__name__)
    try:
        if not json_data:
            logger.warning("The json data is empty.")
            return

        title = json_data.get("title", "No Title")
        sections = json_data.get("sections", [])

        with open(output_file_path, 'a', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            if write_header:
                writer.writerow(["Title", "Content"])
            
            if sections:
                best_content = ""
                max_score = 0
                for section in sections:
                   
                    content = section.get('content',"")
                    score = section.get("score", 0)
                    score = score * 100
                    if score > max_score and score <= 100:
                        max_score = score
                        best_content = content
                
                writer.writerow([title, best_content])
            else:
                logger.warning("No sections found in the json data.")
         
        logger.info(f"Successfully wrote json data to csv file: {output_file_path}")
    except FileNotFoundError as e:
        logger.error(f"FileNotFoundError: {e} when saving to file: {output_file_path}")
    except Exception as e:
         logger.error(f"An unexpected error occurred: {e} when processing data from the JSON: {json_data}. File: {output_file_path}")


if __name__ == '__main__':
    # Example Usage
    logger = configure_logger(__name__)
    
    # Set up argument parser
    parser = argparse.ArgumentParser(description="Converts JSON data to CSV format.")
    
    parser.add_argument("pdf_file_name", help="Name of the PDF file.")
    parser.add_argument("output_json_path", help="Path to output JSON files.")
    parser.add_argument("output_csv_path", help="Path to save the output CSV file.")
    
     # Parse arguments
    args = parser.parse_args()
    #Get the first three characters of the PDF file name
    prefix = args.pdf_file_name[:3]
    
    # Create a timestamp for the output file name
    now = datetime.now()
    # Format the date and time as a string (e.g., '2023-04-06_14-30-00')
    timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
    # Combine the base name, timestamp, and extension to form the file name
    output_file = f"{prefix}combined_vector_db_search_results_{timestamp}.csv"
    
    # Create the full output path
    full_output_path = os.path.join(args.output_csv_path, output_file)
    
    first_file = True
    try:
       
        for filename in os.listdir(args.output_json_path):
            logger.debug(f"Processing file: {filename}")
            if 'query_results' in filename and filename.endswith('.json'):
                 json_file_path = os.path.join(args.output_json_path, filename)
                 logger.info(f"Processing file: {json_file_path}")
                 json_data = {}
                 try:
                    with open(json_file_path, 'r') as f:
                        json_data = json.load(f)
                        json_to_csv_with_max_score(json_data, full_output_path, write_header=first_file)
                        first_file = False
                 except FileNotFoundError as e:
                     logger.error(f"File not found: {json_file_path}. Error: {e}")
                 except json.JSONDecodeError as e:
                     logger.error(f"JSONDecodeError: {e} when loading file: {json_file_path}. Error: {e}")
                 except Exception as e:
                     logger.error(f"An unexpected error occurred: {e} when processing file: {json_file_path}. Error: {e}")
    except FileNotFoundError as e:
        logger.error(f"FileNotFoundError: {e} when listing files in folder: {args.output_json_path}. Error: {e}")
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e} when processing files in folder: {args.output_json_path}. Error: {e}")