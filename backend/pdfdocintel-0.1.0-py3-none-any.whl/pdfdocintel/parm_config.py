import os

class ParmConfig:
  
  def __init__(self, input_dir="files/uploads", output_dir="files/output", json_dir="json", 
               text_dir="text", csv_dir="csv", downloads_dir="files/downloads/api_responses",
               query_dir="query"):
     
     self.input_dir = input_dir
     self.output_dir = output_dir
     self.json_dir = json_dir
     self.text_dir = text_dir
     self.csv_dir = csv_dir
     self.downloads_dir = downloads_dir
     self.query_dir = query_dir
     
     
  def __str__(self):
      return f"ParmConfig(input_dir={self.input_dir}, output_dir={self.output_dir}, json_dir={self.json_dir}, text_dir={self.text_dir})"
       
  def __repr__(self):
    return self.__str__()
      
  def get_output_text_dir(self) -> str: 
      return os.path.join(self.output_dir, self.text_dir)

  def get_output_json_dir(self) -> str:
      return os.path.join(self.output_dir, self.json_dir)
        
  def get_output_csv_dir(self) -> str:
      return os.path.join(self.output_dir, self.csv_dir)
        
  def get_downloads_dir(self) -> str:
      return self.downloads_dir
        
  def get_input_dir(self) -> str:
      return self.input_dir
  
  def get_output_dir(self) -> str:
      return self.output_dir
  
  def get_output_query_dir(self) -> str:
      return os.path.join(self.output_dir, self.query_dir)
        
  def create_directories(self):
      os.makedirs(self.get_output_text_dir(), exist_ok=True)
      os.makedirs(self.get_output_json_dir(), exist_ok=True)
      os.makedirs(self.get_output_csv_dir(), exist_ok=True)
      os.makedirs(self.get_downloads_dir(), exist_ok=True)
      os.makedirs(self.get_output_query_dir(), exist_ok=True)