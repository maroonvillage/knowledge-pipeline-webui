from pdfminer.pdfparser import PDFParser
from pdfminer.pdfdocument import PDFDocument

from logger_config import configure_logger

class EmptyPathError(Exception):
    """Exception raised for empty output path."""
    pass


def extract_toc(pdf_path, output_path=''):
    """
    Extracts the table of contents from a PDF file and saves it to an output file.

    Parameters:
    pdf_path (str): The path to the PDF file.
    output_path (str): The path to the output file to store table of content.

    Raises:
    EmptyPathError: If the output path is empty.
    """
    logger = configure_logger(f"{__name__}.extract_toc")
    if not output_path:
        logger.error("The provided output path is empty.")
        raise EmptyPathError("The provided output path is empty.")
    
    try:
        with open(pdf_path, 'rb') as fp:
            parser = PDFParser(fp)
            document = PDFDocument(parser)

            # Get pages 
            outlines = document.get_outlines()
            with open(output_path, 'w') as file:
                for (level, title, dest, a, se) in outlines:
                    file.write(f"{title}\n")
            logger.info(f"Successfully extracted table of contents from {pdf_path} and saved to {output_path}")
    except FileNotFoundError:
            logger.error(f"File not found: {pdf_path}")
            raise
    except Exception as e:
            logger.error(f"An error occurred: {e}")
            raise