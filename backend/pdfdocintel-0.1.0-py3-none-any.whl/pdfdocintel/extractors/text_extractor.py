from pdfminer.pdfparser import PDFParser
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfpage import PDFPage
from pdfminer.layout import LAParams
from pdfminer.converter import PDFPageAggregator
import tempfile
import os
from typing import List
from logger_config import configure_logger
import utilities.file_util as file_util;
from document import Document, Section;
from pdf_parse_document import PDFParseDocument, Page;
import utilities.parse_util as parse_util;
import processors.element_processors as element_processors;
import utilities.file_util as file_util;

def extract_text_from_pdf(pdf_path):
    """
    Extracts text from a PDF file.

    Parameters:
    pdf_path (str): The path to the PDF file.

    Returns:
        resource_manager = PDFResourceManager()
    """
    logger = configure_logger(f"{__name__}.extract_text_from_pdf")
    try:
        # Open the PDF file
        with open(pdf_path, 'rb') as file:
            # Initialize PDFParser and PDFDocument
            parser = PDFParser(file)
            document = PDFDocument(parser)

            # Create a resource manager to store shared resources
            rsrcmgr = PDFResourceManager()

            # If the document is password-protected, raise an error
            if not document.is_extractable:
                raise ValueError("Text extraction is not allowed for this PDF")

            # Create a resource manager to store shared resources
            rsrcmgr = PDFResourceManager()

            # Use a temporary file to capture the text
            temp_file = tempfile.TemporaryFile(mode='w+b')

            # Set parameters for analysis (e.g., to retain layout)
            laparams = LAParams()  # Using default values

            # Create a TextConverter object to convert PDF pages to text
            device = TextConverter(rsrcmgr, temp_file, laparams=laparams)

            # Create a PDFPageInterpreter object to process each page
            interpreter = PDFPageInterpreter(rsrcmgr, device)

            # Extract text from each page of the document
            pages = list(PDFPage.create_pages(document))
            for page in pages:
                interpreter.process_page(page)

            temp_file.seek(0)
            text = temp_file.read().decode('utf-8')

            return text
    except FileNotFoundError:
         logger.error(f"File not found: {pdf_path}")
         raise # Re-raise the exception to be handled by caller
    except Exception as e:
        logger.error(f"An error occurred during PDF processing: {e}")
        raise #Re-raise to allow caller to catch specific error
    finally:
        # Cleanup
        device.close()
        temp_file.close()

def get_document_sections(file_path: str) -> List[str]:
    """
    Extracts and formats document sections from a JSON file.

    Parameters:
        file_path (str): The path to the JSON file.

    Returns:
        List[str]: A list of formatted document sections.
    """
    logger = configure_logger(f"{__name__}.get_document_sections")
    try:
        json_data = file_util.read_json_file(file_path)
        if not json_data or "sections" not in json_data:
            logger.warning(f"Invalid or missing sections data in JSON file: {file_path}")
            return []

        sections = []
        for section in json_data["sections"]:
            heading = section.get("heading", "")
            paragraphs = " ".join(section.get("paragraphs", []))
            figures = [fig.get("caption", "") for fig in section.get("figures",[])]
            
            sections.append(f"{heading}\n{paragraphs}\n{' '.join(figures)}")
            logger.debug(f"Extracted section: {heading}")
            
        return sections
    except FileNotFoundError:
        logger.error(f"File not found: {file_path}")
        return []
    except TypeError as e:
         logger.error(f"TypeError: {e} invalid json format {file_path}")
         return []
    except KeyError as e:
         logger.error(f"KeyError: {e} invalid json format {file_path}")
         return []
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e} when processing file: {file_path}")
        return []
    
    
def convert_pdf_to_json(pdf_file_path, output_txt_path, output_json_path, lines_list, nlp, header_footer_text, config=None):
    """
    Converts a PDF file to JSON format.
    """
    logger = configure_logger("convert_pdf_to_json")
    logger.info(f'Inside convert_pdf_to_json ... the path is: {pdf_file_path}')
    
    if not config:
        config = {
            "section_pattern": r'^(?:\d+\.\s+)(.+)$',
            "section_pattern_with_group": r'^(?:\d+\.\s+)(.+?)(?:\s+-\s+)(.+)?$',
            "appendix_pattern": r'^(Appendix)\s[A-Z]\.(.*)$',
            "figure_pattern": r'^(Figure|Fig\.)\s\d+.*$',
            "patterns_to_strip": [r'\\u20ac', r'\\n', r'€']
        }

    try:
        document_json = Document(output_json_path,[])
        pdf_parse_document = PDFParseDocument(pdf_file_path, [])
        for line in lines_list:
            cleaned_line = parse_util.strip_characters(line, config["patterns_to_strip"])
            cleaned_line = parse_util.replace_extra_space(cleaned_line)
            document_json.add_section(Section(cleaned_line.strip()))
        current_section_header = ''
        start_page = 3
        with open(output_txt_path, 'w') as wfile:
            with open(pdf_file_path, 'rb') as file:
                parser = PDFParser(file)
                pdf_document = PDFDocument(parser)
                parser.set_document(pdf_document)
                if pdf_document.is_extractable:
                    resource_manager = PDFResourceManager()
                    laparams = LAParams()
                    device = PDFPageAggregator(resource_manager, laparams=laparams)
                    interpreter = PDFPageInterpreter(resource_manager, device)
                    total_pages = len(list(PDFPage.create_pages(pdf_document)))
                    logger.info(f'Total pages for {pdf_file_path}: {total_pages}')
                    page_numbers = set(range(start_page,total_pages))
                    logger.info(f'Page numbers for {pdf_file_path}: {page_numbers}')
                    for page_number, page in enumerate(PDFPage.get_pages(file, pagenos=page_numbers)):
                        interpreter.process_page(page)
                        layout = device.get_result()
                        wfile.write(f'PageId: {page.pageid} Page Number: {page_number}\n')
                        wfile.write(f'This dimensions for this page are: {layout.height} height, {layout.width} width\n')
                        pdf_page = Page(page.pageid, page_number)
                        pdf_page.set_bbox((layout.x0, layout.y0, layout.x1, layout.y1))
                        pdf_parse_document.add_page(pdf_page)
                        for element in layout:
                            try:
                                processor = element_processors.get_element_processor(element, nlp, config)
                                #None
                                current_section_header = processor.process_element(element, document_json, current_section_header, wfile, page=pdf_page, header_footer_text=header_footer_text)
                            except ValueError as ve:
                                   logger.warning(f"Unsupported element type: {element}. Error: {ve}")
                            except Exception as e:
                                  logger.error(f"An error occurred while processing layout element. Element: {element}. Error: {e}")
                else:
                    logger.warning(f"The document {pdf_file_path} is encrypted and cannot be parsed.")
                    
        #Save the JSON file containing the document content
        file_util.save_file(output_json_path, document_json.to_json())
        logger.info(f'Successfully saved document content JSON file: {output_json_path}')
        
        #Save the JSON file containing the PDF elements
        file_name_with_extension = os.path.basename(output_json_path)
        file_name, file_extension = os.path.splitext(file_name_with_extension)
        pdf_elements_file_path = os.path.join(os.path.dirname(output_json_path), f"{file_name}_elements{file_extension}")
        file_util.save_file(pdf_elements_file_path, pdf_parse_document.to_json())
        logger.info(f'Successfully saved document elements JSON file: {pdf_elements_file_path}')

        
    except FileNotFoundError as e:
            logger.error(f"convert_pdf_to_json - {e}")
            raise
    except AttributeError as e:
        logger.error(f"AttributeError in convert_pdf_to_json - {e}")
        raise
    except Exception as e:
            logger.error(f"An error occurred during JSON conversion: {e}")
            raise