from typing import List
from sentence_transformers import SentenceTransformer
import numpy as np
from logger_config import configure_logger

def generate_embeddings(text_chunks: List[str], model_name: str = 'sentence-transformers/all-MiniLM-L6-v2') -> np.ndarray:
    """
    Generates sentence embeddings for a list of text chunks using a SentenceTransformer model.

    Parameters:
        text_chunks (List[str]): A list of text chunks.
        model_name (str): The name or path of the SentenceTransformer model.

    Returns:
        np.ndarray: A numpy array containing the generated embeddings.
    """
    logger = configure_logger("generate_embeddings")
    try:
        logger.info(f"Loading SentenceTransformer model: {model_name}")
        model = SentenceTransformer(model_name)
        logger.debug(f"Successfully loaded SentenceTransformer model: {model_name}")
        section_embeddings = model.encode(text_chunks)
        logger.info(f"Generated embeddings for {len(text_chunks)} text chunks.")
        return section_embeddings
    except Exception as e:
        logger.error(f"An error occurred while generating embeddings using model: {model_name}. Error: {e}")
        return np.array([]) # Return an empty numpy array